
package nueve;


public class Nueve {

    
    public static void main(String[] args) {
        Lanzables l1 = new Lanzables();
        try {
            l1.lanzamiento();
        } catch (Exception e) {
            System.out.println("Mi primera excepcion" + e);
        }
        
    }
    
}
