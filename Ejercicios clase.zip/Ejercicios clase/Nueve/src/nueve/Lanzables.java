

package nueve;


public class Lanzables {
    public int a = 5, b= 10;
    
    public void lanzamiento() throws Exception{
        if(b>5){
            System.out.println("Ya la hice");
            segundoLanzamiento();
        }
        else{
            System.out.println("El mundo se acabo");
            throw new NullPointerException("Se me volvio a acabar");
        }
    }

    public void segundoLanzamiento() throws Exception{ //Avisa que va a mandar un error, aceptar el error 
        throw new Exception("otra excepcion");
    }
    //Lanzamiento dos al uno, el uno al main, y despues arroja todo
}
