

package hilos;



public class Procesus implements Runnable {
Thread hilo;
	
	public Procesus(){
           // JOptionPane.showMessageDialog(null, Thread.currentThread());
             
	}
	
	public Procesus(String nombre){
		//paso 2
		hilo = new Thread(this, nombre);
		System.out.println(hilo.getName());
		//paso 3
		hilo.start();
	}
    @Override
    public void run() {
       
    }

}
