

package hilos;


public class Procesos extends Thread{
   public Procesos(){
       System.out.println("Mi otro hilo");
   }
   
  public Procesos(String nombre){
      super(nombre);
     System.out.println(this);
      start();
     }

    public void run(){
       System.out.println(Thread.currentThread().getName());
          }
}

