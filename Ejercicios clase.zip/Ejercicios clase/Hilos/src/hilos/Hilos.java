
package hilos;

import java.util.logging.Level;
import java.util.logging.Logger;


public class Hilos {

    
    public static void main(String[] args) {
        // TODO code application logic here
        Thread thread1 = new Thread(new Procesos(), "thread1"); //instancia anonima
        Procesos p1 = new Procesos();
        Thread thread2 = new Thread(p1, "thread2"); 
        Thread thread3 = new Thread(new Procesos("Uno"), "thread3");
        Thread thread4 = new Thread(new Procesos(), "thread4");
        Thread thread5 = new Thread(new Procesos(), "thread5");
        Thread thread6 = new Thread(new Procesos(), "thread6");
        
        //objeto anonimo= es dentro de otra variable
        thread1.start();
        thread2.start();
        thread4.start(); 
        thread4.yield(); //cede el paso 
        thread5.start();
        thread6.start();
        try {
            thread6.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Hilos.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(", status = " + thread6.isAlive());
        System.out.println(", status = " + thread3.isAlive());
         
        System.out.println("Esperando los hilos");
        //void main es un hilo más
        try {
			//retraso de un segundo
	   Thread.currentThread().sleep(1000);
	} catch (InterruptedException e) {
	    }
		//Muestra informacion del hilo principal
	System.out.println(Thread.currentThread());
        
        System.out.println("Esperando los hilos");
	}
    
    //aprender teoria de synchronized
    }
    

