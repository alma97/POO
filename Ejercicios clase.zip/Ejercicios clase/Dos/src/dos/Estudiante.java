
package dos;


public class Estudiante {
    private String nombre; //Todo se cambia de tipo privado
    private int edad;
    private String carrera;
    private int semestre;
    public int tiempo;
    

    public Estudiante(String nombre) {
        this.nombre = nombre;
    }
//Get= obtencion
    public int getSemestre() { //public regresa, tiene un return
        return semestre;
    }
    
   // Set= asignacion
    public void setSemestre(int semestre) { //Es de tipo void
        if(semestre<10){
        this.semestre = semestre;
        }
        else{
            System.out.println("Error");
        }
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "nombre=" + nombre + ", edad=" + edad + ", carrera=" + carrera + ", semestre=" + semestre + ", tiempo=" + tiempo + '}';
    }
    
    
    
    
}
