
package dos;


public class Celular {
//insert code= constructor
    public String marca; // Valor global
    public String modelo;
    public double precio; // Cosas que hace el metodo
    public String color;
    public String gama;
    public String proveedor;

    public Celular(String marca, String modelo, double precio, String color, String gama, String proveedor) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.color = color;
        this.gama = gama;
        this.proveedor = proveedor;
    }

    public Celular(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
   
    
    public Celular(String marca, String modelo) { //Se declaran los valores globales
        System.out.println("Se hizo un celular");
        this.marca = marca; 
        this.modelo = modelo;
    }
    
    public void encender(){
        System.out.println("Encendiendo celular marca:" + marca + "modelo:" + modelo);
    }
    
    public void apagar(){
        System.out.println("Apagando celular marca:" + marca + "modelo:" + modelo);
    }
 //Insert code - to string
    @Override
    public String toString() {
        return "Celular{" + "marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + ", color=" + color + ", gama=" + gama + ", proveedor=" + proveedor + '}';
    } // Se accede a cualquier parte del objeto
    
    
}
