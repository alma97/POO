
package dos;


public class Dos {

    
    public static void main(String[] args) {
        Celular c1= new Celular("Sony", "XPERIA Z1"); //Se le dan los datos de entrada
        Celular c2= new Celular("Samsung", "Galaxy S6", 1700.00, "Blanco", "Alta", "AT&T");
        Celular c3= new Celular("Motorola", "Moto G", "Negro");
        
        c1.encender();
        c1.apagar();
        //Con el punto se accede a cualquier cosa
        c2.encender();
        c2.apagar();
        
        c3.encender();
        c3.apagar();
        
        System.out.println(c1) ;
        
        c1.proveedor="Telcel"; // Se accede a cualquier cosa de la clase
        c1.color="Rojo";
        
        System.out.println(c1);
        
        Estudiante e1 = new Estudiante("Aide");
        e1.setSemestre(100); //
        e1.setSemestre(9);
        int sem=e1.getSemestre();
        System.out.println("sem=" + sem); //puede usarlo y regresarlo de cierta manera
        System.out.println("sem=" + e1.getSemestre());
        
        Estudiante e2= new Estudiante("Alma");
        Estudiante e3= new Estudiante ("Alexa");
        Estudiante e4= new Estudiante("Omar");
        Estudiante e5= new Estudiante("David");
        
        e2.setCarrera("IAS");
        e2.setEdad(19);
        e2.setSemestre(5);
        e2.setTiempo(2);
        System.out.println(e2);
        
        e3.setCarrera("IMTC");
        e3.setEdad(20);
        e3.setSemestre(6);
        e3.setTiempo(28);
        System.out.println(e3);
        
        e4.setCarrera("IAS");
        e4.setEdad(18);
        e4.setSemestre(4);
        e4.setTiempo(637);
        System.out.println(e4);
        
        e5.setCarrera("IEA");
        e5.setEdad(22);
        e5.setSemestre(8);
        e5.setTiempo(23);
        System.out.println(e5);
        
        System.out.println(e1);
        
    }
}
    

