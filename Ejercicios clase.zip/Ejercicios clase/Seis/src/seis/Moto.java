

package seis;


public class Moto {
    public String marca;
    public String modelo;

    public Moto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }
    
    

}
