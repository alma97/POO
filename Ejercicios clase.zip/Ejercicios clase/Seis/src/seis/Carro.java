

package seis;


public class Carro {
    
    public String marca;
    public String modelo;

    public Carro(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }
    
    
    public void arrancar(){
        System.out.println("Arranca con 50 hp");
    }
    
    public void apagar(){
        System.out.println("Se apago");
    }

}
