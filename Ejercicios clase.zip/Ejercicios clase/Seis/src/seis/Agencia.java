

package seis;


public class Agencia {
    public void cambioAceite(Carro c1){
        System.out.println("Se cambio el aceite:" + c1.marca + " - " + c1.modelo);
    }

}
