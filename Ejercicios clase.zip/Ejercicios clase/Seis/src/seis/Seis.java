
package seis;


public class Seis {

   
    public static void main(String[] args) {
        Deportivo dd1= new Deportivo("Audi","R8");
       dd1.arrancar(); //Sobreescritura, se utiliza el metodo que es de esa misma clase
       
       Carro cd1 = new Deportivo("Ford","Fiesta"); //Polimorfismo, el padre utiliza los metodos del hijo 
       
        Carro c1 = new Deportivo("VW", "JETTA");
        Carro c2 = new Deportivo("VW","PASSAT");
         Carro c4 = new Deportivo("HONDA", "CIVIC");
         Carro c3 = new Deportivo("TOYOTA","COROLA");
        Carro c5 = new Deportivo("HONDA","ACCORD");
        
        Deportivo d1 = new Deportivo("DODGE", "CHARGER");
        Deportivo d2 = new Deportivo("DODGE", "CHALLENGER");
        Deportivo d3 = new Deportivo("DODGE", "AVENGER");
        Deportivo d4 = new Deportivo("NISSAN", "3502");
        Deportivo d5 = new Deportivo("NISSAN", "SKYLINE");
        
        Agencia a1= new Agencia();
        a1.cambioAceite(c1);
        a1.cambioAceite(d1); //Funciona porque es del tipo padre y del tipo hijo, a como mejor convenga
        
        Moto m1 = new Moto("Italika","Cobra");
      //  a1.cambioAceite(m1 no se puede porque no es del mismo tipo, no tiene nada del carro
      
     if(d1 instanceof Carro){
         System.out.println("Si es un carro");
     }
     else if (c1 instanceof Deportivo){ //Para preguntar si es del tipo, si es del tipo lo ejecuta
         System.out.println("Si es deportivo");
    }
     
     int x=5;
     Integer y = 10; //contiene metodos
     
     String yStr = y.toString(); //convierte al tipo string
     
     String numStr = "un texto";
     String num = numStr.toUpperCase();
     System.out.println(num);
     
     String uno = new String("un texto");
     System.out.println(uno);
     //uno = uno.concat("-otro texto");
    //System.out.println(uno);
    
    if (numStr.equals(uno)){ //cuando no se sabe cuanta cantidad de texto hay que poner, se utiliza de ley 
        System.out.println("Son iguales");
    }
    else {
        System.out.println("No son iguales");
    }
    
   StringBuffer sb = new StringBuffer("Hello world"); 
   System.out.println(sb.length()); 
   System.out.println(sb.capacity());
   sb.append("\nHello World");
   sb.append("\nHello World");
   sb.append("\nHello World");
   sb.append("\nHello World");
   sb.append("\nHello World");
   System.out.println(sb.length()); //Es el numero de caracteres utilizados
   System.out.println(sb.capacity()); //Es la capacidad que puede mantener
   
  sb.substring(6, 11); //Sirve para recortar caracteres, es decir, que empiece desde otra letra
  System.out.println(sb.substring(6));
  
  String tel = "(044) 811-5432-994";
  System.out.println(tel);
  StringBuffer tele = new StringBuffer("(044) 811-5432-994");
  System.out.println(sb.length());
  tele.substring(2, 5);
  tele.append("");
  System.out.println(tele.substring(2,5));
  tele.substring(7, 9);
  System.out.println(tele.substring(7,9));
  tele.substring(11,14);
  System.out.println(tele.substring(11,14));
  tele.substring(16,19);
  System.out.println(tele.substring(16,19));
 
 
 
  String tel2="0448115432994";
  System.out.println(tel2);
  
  StringBuffer tele2 = new StringBuffer("0448115432994");
  
     
   
   StringBuilder sb1 = new StringBuilder("Hello world");
   sb1.append("Hello world");
   sb1.append("Hello world");
   sb1.append("Hello world");
   sb1.append("Hello world");
   
   
   
   
   
   
}
}