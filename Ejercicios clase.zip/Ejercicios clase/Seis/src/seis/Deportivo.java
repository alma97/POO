

package seis;


public class Deportivo extends Carro{ 

    public Deportivo(String marca, String modelo) {
        super(marca, modelo); //Super = para mandar llamar metodos o el constructor del padre
    }
    
    
        @Override // Se pone para indicar la sobreescritura
        public void arrancar(){
System.out.println("Arranca con 100 hp");

}
}