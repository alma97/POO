
package herencia;


public class Herencia {

  
    public static void main(String[] args) {
       Persona p1= new Persona();
       p1.setNombre("Carlos");
       p1.setNacionalidad("Mexicana");
       p1.setFechaNac("01-05-1998");
       p1.setSexo("Masculino");
       p1.setTelefono("8113112878");
      
        Estudiante e1= new Estudiante();
        e1.setNombre("Alma");
        e1.setSemestre(5);
        e1.setCarrera("IAS");
        e1.setSexo("Femenino");
        e1.setFechaNac("01-05-1997");
        e1.setNacionalidad("Mexicana");
        
        Maestro m1= new Maestro();
        m1.setNombre("Juan");
        m1.setFechaNac("23/12/1978");
        m1.setNacionalidad("Mexicana");
        m1.setSexo("Masculino");
        m1.setMateria("Programacion");
        m1.setNumeroEmpleado(1232442);
        m1.setPuesto("Coordinador");
        
        Graduado g1= new Graduado();
        g1.setNombre("Daniela");
        g1.setFechaNac("18/04/1994");
        g1.setNacionalidad("Mexicana");
        g1.setSexo("Femenino");
        g1.setFechaGraduacion("12/3/12");
        g1.setCedula(234343);
                
        
         
        
                
    }
    
}
