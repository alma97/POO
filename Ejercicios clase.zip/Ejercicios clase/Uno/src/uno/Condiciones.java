
package uno;

// Sin el package no se puede realizar ninguna operacion dentro del archivo
public class Condiciones {
    int x = 10;
    int y = 1;
   
    
  public void decision(){
      if(x > y || x == y) // Tres iguales valor y forma
          System.out.println("Es mayor"); // Eñ if se pone sin llaves, forma mas rapida
          else if ( x > y){
                  System.out.println ( "El otro es mayor");
                  }
    //System.out.println(x > y ? " x mayor a y" : " y mayor a x";  forma mas rapida del if
     String result = x > y ? " x mayor a y" : " y mayor a x";
    System.out.println(result);
    
      }
  
  public void ciclo(){
      
      for(int i=0; i<x; i++){ // Con otro mas aumenta en mas medida i+=2
          System.out.println("i=" + i);
      }
      
  
  }
  
  public void opciones(int r){
      switch(r){ // se declara otra variable solo para la parte del switch
          case 1:
              System.out.println("Es uno");
              break;
              case 2:
              System.out.println("Es dos"); // Corre hasta que encuentre un break
              break;
              case 3:
              System.out.println("Es tres");
              break;
              case 4:
              System.out.println("Es cuatro");
              break;
              default:
                  System.out.println("Opcion invalida");
                  break;
         
      }
  }
  
  public void mientras(){ //public void=creacion de un nuevo metodo
      int control = 5;
      int i=0;
      while (i < control){ // Sale del ciclo hasta que la condicion sea falso
          System.out.println("En while i =" + i);
          i++;
      }  
  }
  }
    

