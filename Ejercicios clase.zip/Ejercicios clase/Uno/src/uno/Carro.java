
package uno;

public class Carro {
    
    public String estado;
    
    public void encender(){
    this.estado = "encendido"; //El this es que esta dentro de la misma clase
}   // El this se puede sustituir para no declarar el metodo de tipo string
    public void apagar(){
        this.estado="apagado";
    }
    
    public void arrancar(){
      this.estado="arrancado";
    }
    
    public void detener(){
          this.estado="detenido";
    }
}
