
package uno;

public class Uno { //Nombre de la clase, siempre empieza con mayuscula

    public static void main(String[] args) {
        
        System.out.println("Hola mundo");
        //La ultima parte se llama constructor
        //[Objeto] - [Nombre del objeto (tipo de variable)] = new [constructor];
       Operaciones oper1 = new Operaciones(); //genera objeto
       oper1.suma(5, 7); //objeto con el metodo creado en la otra clase
       oper1.suma(4, 9);
       oper1.suma(3, 6);
       oper1.suma(9, 2);
       
      oper1.imprimir();
      //Creacion de un nuevo objeto
      Carro audi = new Carro();
      audi.encender();
      System.out.println(audi.estado); // Nombre del objeto con el estado
      
      Condiciones cond= new Condiciones();
      cond.decision();
      cond.ciclo();
      cond.opciones(4); // Dependiendo del numero se indica la opcion a elegir
      //No todas las condiciones existen
      cond.mientras();
    }
    
}
