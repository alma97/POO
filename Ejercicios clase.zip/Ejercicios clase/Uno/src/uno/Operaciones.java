
package uno;

public class Operaciones {
    
    public void suma(int a, int b){ // dentro del metodo se identifican el tipo de variables que son
        int c= a+b;
        
        System.out.println(c); //sout + tap = para escribir mas rapido la impresion
           
}
    public void imprimir(){
        int  x = 15;
       // Integer y = 14; variables tipo clase
       float y = 15.0f; // Siempre se le pone una f
       double z = 1.1;
       char c = 'a'; //solo guarda una letra , tiene solo una comilla simple
       boolean b = true; // Solo se pone true o false
       String s = "cadena"; // Es de tipo clase, por eso es con mayuscula
       
       System.out.println("Ejemplo entero:" + x );
        System.out.println("Ejemplo flotante:" + y );
         System.out.println("Ejemplo doble:" + z ); 
          System.out.println("Ejemplo char:" + c );
           System.out.println("Ejemplo boleano:" + b );
            System.out.println("Ejemplo cadena:" + s );
    }
}