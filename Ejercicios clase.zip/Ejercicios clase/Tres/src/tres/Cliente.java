

package tres;


public class Cliente extends Mujer {
private int numSocio;
private int puntos;
private String fechaInscripcion;

    public Cliente(int numSocio, int puntos, String fechaInscripcion, String nombre, int edad, String nacionalidad, String direccion, String fechaNacimiento, int telefono) {
        super(nombre, edad, nacionalidad, direccion, fechaNacimiento, telefono);
        this.numSocio = numSocio;
        this.puntos = puntos;
        this.fechaInscripcion = fechaInscripcion;
    }

   



    public int getNumSocio() {
        return numSocio;
    }

    public void setNumSocio(int numSocio) {
        this.numSocio = numSocio;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public String getFechaInscripcion() {
        return fechaInscripcion;
    }

    public void setFechaInscripcion(String fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }


}
