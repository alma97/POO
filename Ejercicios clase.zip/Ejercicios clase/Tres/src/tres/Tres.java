
package tres;


public class Tres {
    
    
    public static void main(String[]args){
        Emprendedora e1= new Emprendedora(123, "Mty","camioneta", 1627, 278, "01-02-1997", "Alma", 829, "Mexicana", "Apodaca", "01-02-1997", 12);
        e1.setEdad(24);
        e1.setNacionalidad("Mexicana");
        e1.setNombre("Juan");
       e1.setDireccion("Apodaca");
       e1.setVehiculo("Camioneta");
       e1.setTelefono(2528533);
       e1.setPuntos(568);
       System.out.println(e1);
       
       Emprendedora e2= new Emprendedora(123, "Mty","camioneta", 1627, 278, "01-02-1997", "Alma", 829, "Mexicana", "Apodaca", "01-02-1997", 12);
        e2.setEdad(24);
        e2.setNacionalidad("Mexicana");
        e2.setNombre("Juan"); e2.setEdad(24);
      
       e2.setDireccion("Apodaca");
       e2.setVehiculo("Camioneta");
       e2.setTelefono(2528533);
       e2.setPuntos(568);
       System.out.println(e1);
       
       
                
        Cliente c1= new Cliente(2627, 262, "01-03-1098", "Alma", 1233, "Mexicana", "Pesqueria", "01-03-92829", 2297);
        c1.setFechaInscripcion("01-03-2008");
        c1.setFechaNacimiento("01-02-1997");
        c1.setPuntos(10000);
        c1.setNumSocio(2297);
        System.out.println(c1);
        
         Cliente c2= new Cliente(28392, 283, "01-03-2005", "Juan", 36738, "Mexicana", "Apodaca", "01-02-1989", 7383);
        c2.setFechaInscripcion("01-03-2008");
        c2.setFechaNacimiento("01-02-1997");
        c2.setPuntos(10000);
        c2.setNumSocio(2297);
        System.out.println(c2);
         
       
        Mujer m2= new Mujer("Johana", 15, "Mexicana", "San Nicolas", "07-05-1998", 262926);
        m2.setEdad(15);
        m2.setNacionalidad("Mexicana");
        m2.setTelefono(262926);
        m2.setDireccion("San Nicolas");
       System.out.println(m2);
       
        Mujer m3= new Mujer("Kenya", 20, "Mexicana", "Monterrey", "18-4-1997", 197391);
        m3.setEdad(20);
        m3.setNacionalidad("Mexicana");
        m3.setTelefono(197391);
        m3.setDireccion("Monterrey");
        System.out.println(m3);
        
        Mujer m4= new Mujer("Melannie", 13, "Mexicana", "Apodaca", "21-08-1997", 729372);
        m4.setEdad(13);
        m4.setNacionalidad("Mexicana");
        m4.setTelefono(729372);
        m4.setDireccion("Apodaca");
       System.out.println(m4);
       
        Mujer m5= new Mujer("Veronica", 19, "Mexicana", "Guadalupe", "17-01-1997", 393729);
        m5.setEdad(19);
        m5.setNacionalidad("Mexicana");
        m5.setTelefono(393729);
        m5.setDireccion("Guadalupe");
        System.out.println(m5);
        //
        
        
       
        
      
       
        
    }

}
