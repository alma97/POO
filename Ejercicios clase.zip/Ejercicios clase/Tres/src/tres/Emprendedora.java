

package tres;


public class Emprendedora extends Cliente {
private int numCuenta;
private String ruta;
private String vehiculo;

    public Emprendedora(int numCuenta, String ruta, String vehiculo, int numSocio, int puntos, String fechaInscripcion, String nombre, int edad, String nacionalidad, String direccion, String fechaNacimiento, int telefono) {
        super(numSocio, puntos, fechaInscripcion, nombre, edad, nacionalidad, direccion, fechaNacimiento, telefono);
        this.numCuenta = numCuenta;
        this.ruta = ruta;
        this.vehiculo = vehiculo;
    }

    

   

  

    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(String vehiculo) {
        this.vehiculo = vehiculo;
    }

    @Override
    public String toString() {
        return "Emprendedora{" + "numCuenta=" + numCuenta + ", ruta=" + ruta + ", vehiculo=" + vehiculo + '}' + "Cliente{" + "numSocio=" + getNumSocio() + ", puntos=" + getPuntos() + ", fechaInscripcion=" + getFechaInscripcion() + '}' + "Mujer{" + "nombre=" + getNombre() + ", edad=" + getEdad() + ", nacionalidad=" + getNacionalidad() + ", direccion=" + getDireccion() + ", fechaNacimiento=" + getFechaNacimiento() + ", telefono=" + getTelefono() + '}';
  
    

    }
}
