package colecciones;

import java.util.ArrayList;

public class ArrayLista {
    public void two(){
        //Ordenamiento por orden de insercion y permite duplicado
        //Colecciones genericas 
        ArrayList<String> aY = new ArrayList();
        aY.add("Lista");
        aY.add("Ford");
        aY.add("BMW");
        aY.add("VW");
        aY.add("Chevrolet");
        aY.add("Nissan");
        aY.add("Toyota");
        aY.add("Honda");
        aY.add("Nissan");
        //aY.add(13);
        System.out.println(aY.get(2));
        System.out.println(aY.size());
        
        aY.stream().forEach((y) -> {
            System.out.println(y);
        });
        
        aY.remove(5);//Para borrar un elemento de la lista
        aY.clear();//Para borrar todos los elementos de la lista        
        
    }

}
