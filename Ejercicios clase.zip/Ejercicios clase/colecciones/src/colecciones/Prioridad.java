package colecciones;

import java.util.PriorityQueue;

public class Prioridad {
    public void eigth(){
        PriorityQueue pq1 = new PriorityQueue(); 
      PriorityQueue pq2 = new PriorityQueue();
      
      // insert values in the queue
      for ( int i = 3; i  <  10; i++ ){  
         pq1.add (i);
         pq2.add (i);
      }
      
      //peek
      System.out.println ( "Valores iniciales de pq1: "+ pq1);
      Object valPeek = pq1.peek();
      System.out.println ( "El inicio de la fila es (peek): "+ valPeek);
      System.out.println ( "Valores finales de pq1: "+ pq1);
      
      // poll
      System.out.println ( "Valores iniciales de pq2: "+ pq2);
      Object valPoll = pq2.poll();
      System.out.println ( "El inicio de la fila es (poll): "+ valPoll);
      System.out.println ( "Valors despues del metodo poll(): "+ pq2);
    }

}
