package colecciones;

import java.util.TreeSet;

public class TreeSeta {
    public void five(){
        //Orden alfabetico y no permite duplicado
        TreeSet ah=new TreeSet();
        ah.add("Azul");
        ah.add("Amarillo");
        ah.add("Blanco");
        ah.add("Rojo");
        ah.add("Rosa");
        ah.add("Naranja");
        ah.add("Naranja");
        
        for (Object y : ah) {
            System.out.println(y);
            
        }
    }

}
