package colecciones;

import java.util.LinkedList;

public class LinkedLista {
    public void three(){
        LinkedList<String> az=new LinkedList();
        az.add("Monterrey");
        az.add("Apodaca");
        az.add("Guadalupe");
        az.add("Escobedo");
        az.add("Garcia");
        az.add("Monterrey");

        
        az.stream().forEach((y) -> {
            System.out.println(y);
        });
    }

}
