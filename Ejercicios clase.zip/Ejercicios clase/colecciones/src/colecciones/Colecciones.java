package colecciones;

public class Colecciones {

    public static void main(String[] args) {
        //Tipo de objeto-Nombre de la variable=new-Constructor(Se llama igual que la clase)
        Arreglo a1=new Arreglo();
        ArrayLista a2=new ArrayLista();
        LinkedLista a3=new LinkedLista();
        HashSeta a4=new HashSeta();
        TreeSeta a5=new TreeSeta();
        HashMapa a6=new HashMapa();
        TreeMapa a7=new TreeMapa();
        Prioridad a8=new Prioridad();
        
        //a1.one();
        a2.two();
        //a3.three();
        //a4.four();
        //a5.five();
        System.out.println("HashMap");
        a6.six();
        System.out.println("TreeMap");
        a7.seven();
        System.out.println("Priority Que");
        a8.eigth();
    }
    
}
