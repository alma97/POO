package colecciones;

import java.util.HashMap;
import java.util.Set;

public class HashMapa {
    public void six(){
        HashMap<StringBuffer,StringBuilder> ahm=new HashMap();
        ahm.put(new StringBuffer("Azul"),new StringBuilder("Blue"));
        ahm.put(new StringBuffer("Naranja"),new StringBuilder("Orange"));
        ahm.put(new StringBuffer("Rojo"),new StringBuilder("Red"));
        ahm.put(new StringBuffer("Negro"),new StringBuilder("Black"));
        ahm.put(new StringBuffer("Azul"),new StringBuilder("blue"));
        //ahm.forEach(System.out.println("Dos"));
        Set Keys = ahm.keySet();
        for(Object Key:Keys){
            System.out.println(ahm.get(Key) + " " + Key);
        }
    }

}
