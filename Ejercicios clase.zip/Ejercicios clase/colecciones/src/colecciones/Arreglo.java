package colecciones;

public class Arreglo {
    
    public void one(){
        String x[] = new String[5];
        x[0]="hola";
        x[1]="como";
        x[2]="estan";
        x[3]="todos";
        x[4]="en clase";
        
        //For each->Para recorrer cada elemento en un arreglo
        for (String y : x) {
            System.out.println(y);
        }
        
        //System.out.println(y);
        System.out.println(x[2]);
        
    }

}
