package colecciones;

import java.util.HashSet;

public class HashSeta {
    public void four(){
        //Ordenado interno no natural y no permite duplicados
        HashSet ah=new HashSet();
        ah.add("Azul");
        ah.add("Amarillo");
        ah.add("Blanco");
        ah.add("Rojo");
        ah.add("Rosa");
        ah.add("Naranja");
        ah.add("Naranja");
        
        for (Object y : ah) {
            System.out.println(y);
            
        }
    }

}
