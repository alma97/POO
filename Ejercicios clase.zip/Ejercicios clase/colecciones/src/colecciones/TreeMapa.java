package colecciones;

import java.util.Set;
import java.util.TreeMap;

public class TreeMapa {
    public void seven(){
        TreeMap ahm=new TreeMap();
        ahm.put("Azul",new StringBuilder("Blue"));
        ahm.put("Naranja",new StringBuilder("Orange"));
        ahm.put("Rojo",new StringBuilder("Red"));
        ahm.put("Negro",new StringBuilder("Black"));
        ahm.put("Azul",new StringBuilder("blue"));
        
        ahm.remove("Azul");
        Set Keys = ahm.keySet();
        for(Object Key:Keys){
            System.out.println(ahm.get(Key) + " " + Key);
        }

    }

}
