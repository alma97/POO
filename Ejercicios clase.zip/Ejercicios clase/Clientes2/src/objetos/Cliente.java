

package objetos;

import DB.ConexionSql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;


public class Cliente {
    private long id;
    private String nombre;
    private String apellidos;
    private int genero;
    private String email;
    private long telefono;
    private long movil;
    private String ciudad;

    public Cliente(long id, String nombre, String apellidos, int genero, String email, long telefono, long movil, String ciudad) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.genero = genero;
        this.email = email;
        this.telefono = telefono;
        this.movil = movil;
        this.ciudad = ciudad;
    }

    public Cliente(String nombre, String apellidos, int genero, String email, long telefono, long movil, String ciudad) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.genero = genero;
        this.email = email;
        this.telefono = telefono;
        this.movil = movil;
        this.ciudad = ciudad;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getGenero() {
        return genero;
    }

    public void setGenero(int genero) {
        this.genero = genero;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getTelefono() {
        return telefono;
    }

    public void setTelefono(long telefono) {
        this.telefono = telefono;
    }

    public long getMovil() {
        return movil;
    }

    public void setMovil(long movil) {
        this.movil = movil;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    
     public boolean guardar(){
        
        ConexionSql MySql = new ConexionSql();
        Connection conn = MySql.conectar();
        String query= "INSERT INTO clientes (nombre, apellidos, genero, email, telefono, movil,ciudad)"+
                "VALUES('"+this.getNombre()+"','"+this.getApellidos()+"','"+this.getGenero()+"','"+this.getEmail()+
                "','"+this.getTelefono()+"','"+this.getMovil()+"','"+this.getCiudad()+"')";    
        boolean val = false;
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            int rowsA = ps.executeUpdate();
            if(rowsA!= 0)
                val=true;
            else
                val=false;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "ERROR"+ ex);
        }
        
         return val;
    }
    
    public boolean modificar(){
        ConexionSql conecionMySql = new ConexionSql();
        Connection conn = conecionMySql.conectar();
        String query ="UPDATE clientes SET nombre = '"+this.getNombre()+"' ,apellidos = '"+this.getApellidos()+"',genero = '"
                +this.getGenero()+"',email = '"+this.getEmail()+"',telefono = '"+this.getTelefono()+"',movil = '"
                +this.getMovil()+"',ciudad = '"+this.getCiudad()+"'"+
                "WHERE id="+this.getId();
                boolean val = false;
                System.out.println(query);
                try{
                    PreparedStatement ps = conn.prepareStatement(query);
                    int rowsA = ps.executeUpdate();
                    if (rowsA != 0){
                        val=true;
                            }else{
                        val=false;
                        }
                }catch(Exception e){
                    JOptionPane.showMessageDialog(null, "Error3: "+e);
                    val=false;
                    } 
                return val;
          }
    
    
    
    
    public boolean eliminar(){
        boolean val = false;
        ConexionSql conexionMySql = new ConexionSql();
        Connection conn = conexionMySql.conectar();
        
        String query="DELETE FROM clientes WHERE id="+this.getId();
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int deleteOk = ps.executeUpdate();
            if(deleteOk != 0)
                val=true;
            else
                val=false;
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null, "Error4: "+e);
            val=false;
        }
        return val;
    }
    
  
           
        
    }
    


