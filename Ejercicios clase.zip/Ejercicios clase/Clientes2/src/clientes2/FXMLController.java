/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientes2;

import DB.ConexionSql;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.ContextMenuEvent;
import javax.swing.JOptionPane;
import objetos.Cliente;

/**
 * FXML Controller class
 *
 * @author Alma
 */
public class FXMLController implements Initializable {

    @FXML
    private TextField txtID;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApellidos;
    @FXML
    private RadioButton rbtnH;
    @FXML
    private ToggleGroup grupo;
    @FXML
    private RadioButton rbtnM;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtTelefono;
    @FXML
    private TextField txtMovil;
    @FXML
    private TextField txtCiudad;
    @FXML
    private Button btnNuevo;
    @FXML
    private Button btnGuardar;
    @FXML
    private Button btnCancelar;
    @FXML
    private TableView<Cliente> tablaClientes;
    @FXML
    private TableColumn<Cliente, Long> columnaID;
    @FXML
    private TableColumn<Cliente, String> columnaNombre;
    @FXML
    private TableColumn<Cliente, String> columnaApellidos;
    @FXML
    private TableColumn<Cliente, Integer> columnaGenero;
    @FXML
    private TableColumn<Cliente, String> columnaEmail;
    @FXML
    private TableColumn<Cliente, Long> columnaTelefono;
    @FXML
    private TableColumn<Cliente, Long> columnaMovil;
    @FXML
    private TableColumn<Cliente, String> columnaCiudad;

     public ObservableList<Cliente> data = FXCollections.observableArrayList();
     
     private void setTable(){
        columnaID.setCellValueFactory(
                new PropertyValueFactory<>("id"));
        
        columnaNombre.setCellValueFactory(
                new PropertyValueFactory<>("nombre"));
        
        columnaApellidos.setCellValueFactory(
                new PropertyValueFactory<>("apellidos"));
        
        columnaGenero.setCellValueFactory(
                new PropertyValueFactory<>("genero"));
        
        columnaEmail.setCellValueFactory(
                new PropertyValueFactory<>("email"));
        
        columnaTelefono.setCellValueFactory(
                new PropertyValueFactory<>("telefono"));
        
        columnaMovil.setCellValueFactory(
                new PropertyValueFactory<>("movil"));
        
        columnaCiudad.setCellValueFactory(
                new PropertyValueFactory<>("ciudad"));
        
        tablaClientes.setItems(data);
    }
    
       private void rellenarTabla(){
        data.clear();
        
        String query= "SELECT * FROM clientes";
        ConexionSql conexion1 = new ConexionSql();
        Connection conn = conexion1.conectar();
        
        Statement stQuery;
        try{
            stQuery=conn.createStatement();
            ResultSet rsResultado = stQuery.executeQuery(query);
            while(rsResultado.next()){
                data.add(new Cliente(rsResultado.getLong("id"), rsResultado.getString("nombre"), rsResultado.getString("apellidos"), 
                       rsResultado.getInt("genero"), rsResultado.getString("email"), rsResultado.getLong("telefono"), 
                        rsResultado.getLong("movil"), rsResultado.getString("ciudad")));
            }
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Error al rellenar tabla: "+ e); 
        }
    }
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        setTable();
        rellenarTabla();
    }    

    @FXML
    private void btnNuevo_click(ActionEvent event) {
        txtApellidos.setDisable(false);
        txtCiudad.setDisable(false);
        txtEmail.setDisable(false);
        txtID.setDisable(true); 
        txtMovil.setDisable(false);
        txtNombre.setDisable(false);
        txtTelefono.setDisable(false);
        rbtnH.setDisable(false);
        rbtnM.setDisable(false);
        
        btnNuevo.setDisable(true);
        btnGuardar.setDisable(false);
        btnCancelar.setDisable(false);
    }

    @FXML
    private void btnGuardar_click(ActionEvent event) {
          if(txtApellidos.getText().trim().equals("") || txtCiudad.getText().trim().equals("") || txtEmail.getText().trim().equals("") || 
                 txtMovil.getText().trim().equals("") || txtNombre.getText().trim().equals("") || 
                txtTelefono.getText().trim().equals("") )
        {
            JOptionPane.showMessageDialog(null, "Favor de llenar todos los campos");
        }else{
            
            int genero=0;
            if(rbtnH.isSelected() ==true) genero=2;
            if(rbtnM.isSelected() == true) genero=1;
            if(rbtnH.isSelected() == false && rbtnM.isSelected()== false ) JOptionPane.showMessageDialog(null, "Seleccione el genero");
                    
            
            if(txtID.getText().trim().equals("")){
                Cliente cliente = new Cliente(txtNombre.getText(), txtApellidos.getText(),genero , txtEmail.getText(),Long.parseLong(txtTelefono.getText()),
                        Long.parseLong(txtMovil.getText()), txtCiudad.getText());
                cliente.guardar();
            }
            else{
                Cliente cliente1 = new Cliente(Long.parseLong(txtID.getText()), txtNombre.getText(), txtApellidos.getText(), genero , txtEmail.getText(),
                        Long.parseLong(txtTelefono.getText()), Long.parseLong(txtMovil.getText()), txtCiudad.getText());
                cliente1.modificar();
            }
            
        txtApellidos.setText("");
        txtCiudad.setText("");
        txtEmail.setText("");
        txtID.setText("");
        txtMovil.setText("");
        txtNombre.setText("");
        txtTelefono.setText("");
        rbtnH.setText("H");
        rbtnM.setText("M");
        
        btnNuevo.setDisable(false);
        btnGuardar.setDisable(true);
        btnCancelar.setDisable(true);
        
        rellenarTabla();
        }
            
    }

    @FXML
    private void btnCancelar_click(ActionEvent event) {
        txtApellidos.setText("");
        txtCiudad.setText("");
        txtEmail.setText("");
        txtID.setText("");
        txtMovil.setText("");
        txtNombre.setText("");
        txtTelefono.setText("");
        
        txtApellidos.setDisable(true);
        txtCiudad.setDisable(true);
        txtEmail.setDisable(true);
        txtID.setDisable(true);
        txtMovil.setDisable(true);
        txtNombre.setDisable(true);
        txtTelefono.setDisable(true);
        rbtnH.setDisable(true);
        rbtnM.setDisable(true);
        
        
        
        btnNuevo.setDisable(false);
        btnGuardar.setDisable(true);
        btnCancelar.setDisable(true);
    }

    @FXML
    private void tablaClientes_contextMenu(ContextMenuEvent event) {
         ContextMenu menu = new ContextMenu();
        MenuItem itemEditar = new MenuItem("Editar");
        itemEditar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
              txtNombre.setDisable(false);
              txtApellidos.setDisable(false);
              txtEmail.setDisable(false);
              txtTelefono.setDisable(false);
              txtMovil.setDisable(false);
              txtCiudad.setDisable(false);
              
              rbtnH.setDisable(false);
              rbtnM.setDisable(false);
              
              btnNuevo.setDisable(true);
              btnGuardar.setDisable(false);
              btnCancelar.setDisable(false);
              
              Cliente cliente = tablaClientes.getSelectionModel().getSelectedItem();
              txtNombre.setText(cliente.getNombre());
              txtApellidos.setText(cliente.getApellidos());             
              txtEmail.setText(cliente.getEmail());
              txtTelefono.setText(String.valueOf(cliente.getTelefono()));
              txtMovil.setText(String.valueOf(cliente.getMovil()));
              txtCiudad.setText(cliente.getCiudad());
            }
        });
        
         MenuItem itemEliminar = new MenuItem("Eliminar");
        itemEliminar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
               Cliente cliente = tablaClientes.getSelectionModel().getSelectedItem();
               int option = JOptionPane.showConfirmDialog(null,"Desea eliminar el registro?","Confirmacion",JOptionPane.YES_NO_OPTION,2);
					if(option == JOptionPane.YES_OPTION){
						cliente.eliminar();
						rellenarTabla();
					}
				}
            
        });
        menu.getItems().add(itemEditar);
        menu.getItems().add(itemEliminar);
        tablaClientes.setContextMenu(menu);   
    

 
    }
    
}
