

package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class ConexionSql {
 public String db = "crm";
  public String url = "jdbc:mysql://127.0.0.1/" + db; //nombre del servidor
  public String user = "root"; 
  public String pwd = "";
  
  public Connection conectar(){
  Connection link = null;
  try{
      Class.forName("org.gjt.mm.mysql.Driver"); // es el que hace la conexion
      link = DriverManager.getConnection(this.url, this.user, this.pwd); 
       JOptionPane.showMessageDialog(null, "Conexion exitosa");
  }catch(Exception e){
      //En caso de que falle la conexion manda un mensaje 
      JOptionPane.showMessageDialog(null, "Error" + e);
  }
  return link;
  }
}
