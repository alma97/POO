

package DB;




public class testConexion {
public static void main(String[] args){
        ConexionSql cm = new ConexionSql ();
        cm.conectar();
}
}
