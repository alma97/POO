

package cuatro;


public class Gcien extends Estudiante{
    private String promedio;

    public Gcien(String promedio, int matricula, String carrera, String nombre) {
        super(matricula, carrera, nombre);
        this.promedio = promedio;
    }

    public String getPromedio() {
        return promedio;
    }

    public void setPromedio(String promedio) {
        this.promedio = promedio;
    }
    
   @Override //para que funcione más rápido
     public void inscribirse(){
        System.out.println("Paga mitad colegiatura ");
    }


}
