

package cuatro;


public class PrimerIngreso extends Interesado{

    public PrimerIngreso(String nombre) {
        super(nombre);
    }

    @Override
    public void pagoInscripcion() {
    }

    @Override
    public void solicitarBeca() {
       
    }
    

}
