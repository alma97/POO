

package cuatro;


public class Estudiante extends Persona {
private int matricula;
private String carrera;

    public Estudiante(int matricula, String carrera, String nombre) {
        super(nombre);
        this.matricula = matricula;
        this.carrera = carrera;
    }

    @Override //Implement method, para poner el que no se pus en la clase anterior
    public void solicitarBeca() {
      System.out.println("Solicitar beca");
    }

  

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }
  
   
    public void inscribirse(){
        System.out.println("Paga colegiatura completa");
    }
    
    public void baja(){
        System.out.println("Se dio de baja");
    }

}
