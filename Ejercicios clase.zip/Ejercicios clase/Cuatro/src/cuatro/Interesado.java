

package cuatro;


public abstract class Interesado extends Persona{

    public Interesado(String nombre) {
        super(nombre);
    }
    
    public abstract void pagoInscripcion();

}
