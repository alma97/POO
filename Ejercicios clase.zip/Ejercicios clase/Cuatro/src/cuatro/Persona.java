

package cuatro;


public abstract class Persona {
    private String nombre;
    private String fechaNac;
    private String genero;
    
    public void matricularse(){
    System.out.println("Matricularse");
    }
    
    public abstract void solicitarBeca(); //Metodo que no está implementado

    public Persona(String nombre) {
        this.nombre = nombre;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    
    
    

}
