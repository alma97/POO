
package cuatro;


public class Cuatro {

   
    public static void main(String[] args) {
        Estudiante e1= new Estudiante(1616981, "IAS", "Alma"); //CLASE ABSTRACTA: No se puede instanciar, NO SE CREA IGUAL EL OBJETO EERSONA, TIENE QUE SER HEREDADO DE OTRA CLASE
        Estudiante e2= new Estudiante(1616892, "ITS", "Chuy"); 
        Estudiante e3= new Estudiante( 175389, "IEC", "Fer"); 
        Estudiante e4= new Estudiante(1616341, "IAE", "Denisse"); 
           
            
       Gcien g1= new Gcien("9", 2637293, "IAS", "Omar");
       Gcien g2= new Gcien("100", 1616981, "ITS", "Alejandro");
       Gcien g3= new Gcien("99", 1617994, "IEC", "Daniela");
       
       Persona pe= new Estudiante(1616981, "", "");
       Persona pg= new Gcien("", 1617994, "", "");
              
        e1.inscribirse();
        e2.inscribirse();
        e3.inscribirse();
        e4.inscribirse();
        
        g1.inscribirse();
        g2.inscribirse();
        g3.inscribirse();
        g2.baja();
        e1.matricularse();
        
              
    }
    
}
