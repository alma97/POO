
package siete;


public interface Carro {
    
    // Para declarar una constante
    // String ALGO="";
    
    void encender();
    void apagar();
    
    
}
