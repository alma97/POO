
package siete;


public class Siete {

   
    public static void main(String[] args) {
        System.out.println(Bebidas.CAPUCHINO.leche);
        preparar(Bebidas.AMERICANO);
       
       
    }
    
    public static void preparar(Bebidas bebida){
        System.out.println("leche=" + bebida.leche);
        System.out.println("cafe=" + bebida.cafe);
    }
    
}
