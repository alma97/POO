

package siete;


public class Vehiculo extends Tipo implements Carro, Deportivo { //se pueden implementar mas interfaces

    @Override
    public void encender() {
        
    }

    @Override
    public void apagar() {
        
    }

    @Override
    public void elTurbo() {
       
    }

}
