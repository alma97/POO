
package siete;


public enum Bebidas {
    CAPUCHINO("Tres", "dos"),
    AMERICANO("nada","dos"),
    MOKA("nada","dos"),
    CHOCOLATE("tres","dos"),
    LATTE("nada","dos"),
    EXPRESSO("nada","seis"),
    MACHIATO("tres","tres");
    
    public String leche;
    public String cafe;

    private Bebidas(String leche, String cafe) {
        this.leche = leche;
        this.cafe = cafe;
    }
    
    
}
