
 
package siete;


public interface Deportivo {
    void elTurbo();
    
    
}
