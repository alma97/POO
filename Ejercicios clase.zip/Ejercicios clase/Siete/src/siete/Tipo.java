

package siete;


public class Tipo {
    public String marca;
    public String modelo;
    public String anio;
    

}
