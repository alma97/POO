

package ocho;


class nulo1 {

}
