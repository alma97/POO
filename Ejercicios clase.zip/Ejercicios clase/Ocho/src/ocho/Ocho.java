
package ocho;


public class Ocho {

    
    public static void main(String[] args) {
        //Error aritmetico
        
        int x = 5;
        int y = 0;
        String nulo1= null;
        //Para que siga ejecutando correctamente el programa
        try {
         nulo1.concat("");
            int []enteros=new int[-3];
            System.out.println(x/y); 
        } catch (ArithmeticException e) { //nada mas arroja errores aritmeticos, truena pero no lo cacha
            System.out.println("Mi primer excepcion" + e);
        }catch(NegativeArraySizeException e2){
            System.out.println("Mi primera excepcion" + e2);
        }catch(Exception e  ){
            System.out.println("Quinta excepcion" + e);
            nulo1 = "valor";
        }
       
        System.out.println(nulo1);
        
        int w=0, f=0;
        if(10>5){
             w = 1;
        }
        else{
             f =5;
        }
        System.out.println( w + f);
        
        //Error pot index fuera de limites
        int[] valores = {5,4,3,2,1};
        try{
        System.out.println(valores[0]);
       // System.out.println(valores[8]);
       System.out.println(valores[-8]);
        System.out.println("mas cosas");
        }catch(Exception e){
            System.out.println("Segunda excepcion" + e);
        }
        
        //Error por valor nulo
        String nulo = null;
        try{
        nulo.concat("blabla");
        } catch (Exception e){
            System.out.println("Tercera excepcion" + e);
        }finally{ 
            System.out.println("Gracias por participar");
        }
        
       
        //Error por indice negativo
        try{
        int [] enteros = new int [-3];
        }catch(Exception e  ){
            System.out.println("Cuarta excepcion" + e);
        }
        
    }
    
}
