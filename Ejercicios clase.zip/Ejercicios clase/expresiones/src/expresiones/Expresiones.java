package expresiones;

public class Expresiones {

    public static void main(String[] args) {
        PatternEjemplo p1 = new PatternEjemplo();
        
        p1.start();
        
    }
    
}
