

package cinco;


public class Deportivo extends Carro {
public int hp = 100;
public String name = "highway";

public void go(){
    System.out.println("45 north");
}

    @Override
    public String toString() {
        return "Deportivo{" + "hp=" + hp + ", name=" + name + '}';
    }


}
