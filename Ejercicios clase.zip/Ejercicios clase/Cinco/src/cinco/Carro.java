

package cinco;


public class Carro {
public int hp= 50;
public String name = "city";

public void go(){
    System.out.println("Go Monterrey");
}

    @Override
    public String toString() {
        return "Carro{" + "hp=" + hp + ", name=" + name + '}';
    }


}
