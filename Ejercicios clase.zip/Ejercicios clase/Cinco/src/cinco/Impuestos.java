

package cinco;


public final class Impuestos {
    
    public static double FACTOR = 0.16;  //nadie lo puede modificar //A PARTIR DE AQUI SE HACEN LAS CONSTANTES
    
public static double iva(double value){ 
    return (value * FACTOR);
}
}
