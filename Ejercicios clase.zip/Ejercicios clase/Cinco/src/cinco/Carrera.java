

package cinco;


public class Carrera extends Deportivo{
public int hp= 150;
public String name = "race";

public void go(){
    System.out.println("Go Derby");
}

    @Override
    public String toString() {
        return "Carrera{" + "hp=" + hp + ", name=" + name + '}';
    }


}
