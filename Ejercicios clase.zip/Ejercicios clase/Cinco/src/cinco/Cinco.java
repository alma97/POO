
package cinco;


public class Cinco {

    
    public static void main(String[] args) {
       Carro c1 = new Carro();
       Deportivo d1= new Deportivo();
       Carrera ca1 = new Carrera();
       
       System.out.println(c1);
       c1.go();
       System.out.println(d1);
       d1.go();
       System.out.println(ca1);
       ca1.go();
       
       //Polimorfismo
       Carro cd = new Deportivo();
       System.out.println(cd.hp);
       Carro ccr = new Carrera();
       Deportivo dcr = new Carrera();
       
       System.out.println(cd);
       cd.go();
       System.out.println(ccr);
       ccr.go();
       System.out.println(dcr);
       dcr.go();
        
      // clase final=prototipo
       double calculo;
       calculo= 18.23;
       System.out.println("calculo = " + calculo);
       System.out.println("sin = " + Math.sin(calculo));
       System.out.println("ceil =" + Math.ceil(calculo));
       System.out.println("sqrt=" + Math.sqrt(calculo));
       System.out.println("abs =" + Math.abs(calculo));
       System.out.println("exp" + Math.exp(calculo));
       System.out.println("cos = " + Math.cos(calculo));
       System.out.println("floor= " + Math.floor(calculo));
       
       double iva = Impuestos.iva(calculo);
       System.out.println(iva);
       System.out.println(Impuestos.FACTOR);
    }
    
}
